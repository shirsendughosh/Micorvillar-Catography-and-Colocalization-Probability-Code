function createfigure_subplot2type1_shade_Roi(data1,data2,whichtype,title1,title2,range_x,range_y,View_range)
switch whichtype
    case 1 % surf
 
% Create figure
figure1 = figure;colormap gray(128);
%hold on 
subplot1=subplot(1,2,1,'Parent',figure1);
view(subplot1,View_range);
grid(subplot1,'on');
hold(subplot1,'all');
surf(data1,'Parent',subplot1,'EdgeColor','none');
title(title1,'Fontsize',12);
[OriZLim]=get(subplot1,'ZLim');
zlim(OriZLim)
xlim(range_x);
ylim(range_y);
zlabel('\delta z (nm)');
shading interp;
light;
lighting phong;
% Create subplot
subplot2 = subplot(1,2,2,'Parent',figure1); 
view(subplot2,View_range); %[-80 3]]
grid(subplot2,'on');
hold(subplot2,'all');
% Create subplot
surf(data2,'Parent',subplot2,'EdgeColor','none');
title(title2,'Fontsize',12);
zlim(OriZLim)
xlim(range_x);
ylim(range_y);
zlabel('\delta z (nm)')
shading interp;
light;
lighting phong;

hold off

    case 2
figure1 = figure;
%hold on 
subplot1=subplot(1,2,1,'Parent',figure1);
%view(subplot1,[90 0]);
grid(subplot1,'on');
hold(subplot1,'all');
imagesc(data1,'Parent',subplot1);
colorbar('SouthOutside')
title(title1,'Fontsize',12);

xlim([range_x]);
ylim([range_y]);
axis equal tight;
% [OriZLim]=get(subplot1,'ZLim');
% zlim(OriZLim)
%zlabel('\delta z (nm)')
% Create subplot
subplot2 = subplot(1,2,2,'Parent',figure1); 
%view(subplot2,[90 0]); %[-80 3]]
grid(subplot2,'on');
hold(subplot2,'all');
% Create subplot
imagesc(data2,'Parent',subplot2);
colorbar('SouthOutside')
title(title2,'Fontsize',12);
xlim(range_x);
ylim(range_y);
axis equal tight;
% zlim(OriZLim)
% zlabel('\delta z (nm)')
hold off
end
end





% Create surf


