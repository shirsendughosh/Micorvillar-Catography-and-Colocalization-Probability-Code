function [resultImage]=VA_STORM_merge(stormcolor,myColorMap,VARec,StormData,StormfileName,focalplane,local_scale,range_x,range_y,markersize,zMax)
%VARec = meanLocDeltaZ;
%% Merge Two figures 
% colormap('gray');
if focalplane==0
focalplanename='0nm';
elseif focalplane==-4
focalplanename='-400nm';
else
    'error'
end
% figure;
% resultImage = image(VARec, 'CDataMapping', 'scaled');
%resultImage = pcolor(VARec);

% switch VAtype
%     case 1
%     VARec = VAdata.meanLocDeltaZ;
%     case 2
%     VARec = VAdata.z;
%     case 3
%     VARec = VAdata.MeanSTDdelta{1};
% end 
% 
% resultImage = imagesc(VARec);
% set(gca,'YDir','normal')

% myColorMap = colormap('gray(16)'); %set the colormap used  %autumn
% %myColorMap =(flipud(myColorMap));
colormap(myColorMap)
resultImage = imagesc(VARec);
set(gca,'YDir','normal')
colorbar
caxis([0 zMax]) 
axis equal; 
% set(resultImage,'EdgeColor','none')
% view ([0 90])
%axis resultImage;

hold all;

% %  colormap('gray');
% % scatter(postData(:,2), postData(:,1), 1, postData(:,3),'MarkerEdgeColor',[1 0 0]);
%scatter(postData1shift(:,2), postData1shift(:,1), 2, '+','MarkerEdgeColor',[0 0.5 0.5]);

%scatter(StormData(:,2), StormData(:,1), 2,'o','filled','MarkerEdgeColor',stormcolor,'MarkerFaceColor',stormcolor);

scatter(StormData(:,2), StormData(:,1), 3,'*','MarkerEdgeColor',stormcolor);

set(gca,'LooseInset',get(gca,'TightInset'))
% [focalplane]= GetPartName(sourceDataName,'um');
title(['focal plane: ',focalplanename],'Fontsize',16);
% 
% [focalplane]= GetPartName(sourceDataName,'um');
% 
SaveName=['VASTORM_',StormfileName(1:end-4)];
% 
if length(StormfileName)>60 
    SaveName = [SaveName(1:60),'_',focalplanename];% type char
end
saveas(gcf,[SaveName]);%,'jpg');    

% 
if local_scale==1;
    
addscale3_um_range(range_x,range_y,markersize)

    saveas(gcf,['scale' SaveName]);%,'jpg'); 
    set(gcf, 'Position', get(0, 'ScreenSize')); 
    saveas(gcf,['scale' SaveName],'jpg'); 
end
%close; 
hold off
end
% focalplane =-400nm
% 
% figure 
% resultImage = imagesc(VARec);
% set(gca,'YDir','normal')
% myColorMap = colormap('hsv(16)'); %set the colormap used  %autumn
% myColorMap =(flipud(colormap('jet(8)')));
% colorbar
% caxis([0 600]) 
% axis equal; 
% set(resultImage,'EdgeColor','none')
% view ([0 90])
% axis resultImage;
% hold all;
% if dual focalplane==1
% scatter(postData2shift(:,2), postData2shift(:,1), 2, '+','MarkerEdgeColor',[0 0 0]);
% set(gca,'LooseInset',get(gca,'TightInset'))
% title(['focal plane: -400nm'],'Fontsize',12);
% 
% [focalplane]= GetPartName(sourceDataName2,'um');
% 
% SaveName=sourceDataName2;
% 
% if length(sourceDataName2)>60 
%     SaveName = [sourceDataName2(1:50),'_',focalplane];% type char
% end
% 
% saveas(gcf,[SaveName]);%,'jpg');    
% 
% if local_scale==1;
% addscale3_um_range(range_x,range_y,markersize);
%    saveas(gcf,['scale_' SaveName]);%,'jpg');    
% close; 
% 
% %% dual focal plane merge
% 
% figure;
% resultImage = imagesc(VARec);
% set(gca,'YDir','normal')
% 
% myColorMap = colormap('hsv(16)'); %set the colormap used  %autumn
% % myColorMap =(flipud(colormap('jet(8)')));
% colorbar
% caxis([0 600]) 
% axis equal; 
% % set(resultImage,'EdgeColor','none')
% % view ([0 90])
% %axis resultImage;
% 
% hold all;
% 
% %  colormap('gray');
% % scatter(postData(:,2), postData(:,1), 1, postData(:,3),'MarkerEdgeColor',[1 0 0]);
% %scatter(postData1shift(:,2), postData1shift(:,1), 2, '+','MarkerEdgeColor',[0 0.5 0.5]);
% scatter(postData1shift(:,2), postData1shift(:,1), 2, '+','MarkerEdgeColor',[0 0 0]);
% %hold all;
% scatter(postData2shift(:,2), postData2shift(:,1), 2, '+','MarkerEdgeColor',[0 0.5 0.5]);
% title(['dual focal plane'],'Fontsize',12);
% set(gca,'LooseInset',get(gca,'TightInset'))
% 
% 
% SaveName=sourceDataName;
% 
% if length(sourceDataName)>60 
%     SaveName = [sourceDataName(1:50),'_',focalplane];% type char
% end
% 
% saveas(gcf,['Dual_' SaveName]);%,'jpg');    
% 
% if local_scale==1;
%     
% addscale3_um_range(range_x,range_y,markersize);
% 
%    saveas(gcf,['Dual_' SaveName]);%,'jpg');    
% 
% end
