clc; clear all; close all;
delta=10;
scale_length=500;
pixel_size=66.67;
folder_data = uigetdir;
Samplpath = [folder_data '\'];
Listing = dir([Samplpath,'*.fits']);
cd (Samplpath)
for nn= 1:size(Listing,1)
    filename= Listing(nn).name;
    SLN{nn}=filename;
end
[Path_ALLFITPT,Path_Reconstruction_folder,FileDimention]=CP_CFSTORM_analysis(SLN,Samplpath);
%% Asking user for fiduciary location and range of intereset
path_rec=[Path_Reconstruction_folder '\'];
Listing_1 = dir([path_rec,'*.mat']);
cd(path_rec)
for ff=1:size(Listing_1,1)
if ~isempty(strfind(Listing_1(ff).name,'FitsetPT'))
if (strcmp(Listing_1(ff).name((end-8):(end-4)),'ex532'))
load(Listing_1(ff).name)
FM_ex532=FitsetPT(:,2);
FN_ex532=FitsetPT(:,3);
clear FitsetPT
end
if (strcmp(Listing_1(ff).name((end-8):(end-4)),'ex642'))
load(Listing_1(ff).name)
FM_ex642=FitsetPT(:,2);
FN_ex642=FitsetPT(:,3);
clear FitsetPT
end
end
end
tiledlayout(1,2)
nexttile
scatter(FN_ex532,FM_ex532,10,[0 1 0],'filled')
axis equal
xlim([0 FileDimention(2)]);
ylim([0 FileDimention(1)]);
title('Plot green')
nexttile; 
scatter(FN_ex642,FM_ex642,10,[1 0 0],'filled')
axis equal
xlim([0 FileDimention(2)]);
ylim([0 FileDimention(1)]);
title('Plot red')
fid=input('what is the x and y location of fiduciary');
x_range=input('what is the region of interest in x');
y_range=input('what is the region of interest in y');
scale_x=[(x_range(1)+2) (x_range(1)+2+(scale_length/pixel_size))];
scale_y=[(y_range(1)+2) (y_range(1)+2)];
%% loading all Fitpt files
pathall=[Path_ALLFITPT '\'];
Listing_all = dir([pathall,'*.mat']);
cd (pathall)
for nn= 1:size(Listing_all,1)
    filename= Listing_all(nn).name;
    FNlist{nn}=filename;
end
%% Finding Fiduciary of all movies and creating fidptchar
for ff=1:size(FNlist,2)
    load(FNlist{ff});
    getparts = strread(FNlist{ff},'%s','delimiter','.');
    getparts2= strread(getparts{1},'%s','delimiter','_');
    getName    = char(getparts2(2));
    getex    = char(getparts2(4));
    getnom = cell2mat(getparts2(5)); %no of movie
    Length_1Movie_green=size(FitoutPT,1);
    fidxtot=0;
    fidytot=0;
    fidavgx=0;
    fidavgy=0;
    fidcounter=0;
    for aa=1:Length_1Movie_green
            if (FitoutPT(aa,2) >= (fid(2)-3)) && (FitoutPT(aa,2) <= (fid(2)+3))&& (FitoutPT(aa,3) >= (fid(1)-3)) && (FitoutPT(aa,3) <= (fid(1)+3))
                  fidxtot=fidxtot+FitoutPT(aa,2);
                  fidytot=fidytot+FitoutPT(aa,3);
                  fidcounter=fidcounter+1;
            end
    end
            fidavgx=fidxtot/fidcounter;
            fidavgy=fidytot/fidcounter;
    if (getex=='ex532')
        if (getnom=='00')
            fidx=fidavgx;
            fidy=fidavgy;
       end
    end
    fidptchar(ff,1)=num2cell(ff);
    fidptchar(ff,2)={getName};
    fidptchar(ff,3)={getex};
    fidptchar(ff,4)={getnom};
    
    fidptchar(ff,5)=num2cell(fidavgx);
    fidptchar(ff,6)=num2cell(fidavgy);
    
end
%% Final Correction
'making correction'
FitoutPT_all_green=zeros(1,10);
FitoutPT_all_red=zeros(1,10);
for ff=1:size(FNlist,2)
    load(FNlist{ff});
    corrx=0;
    corry=0;
    getnom = str2num(cell2mat(fidptchar(ff,4))); %no of movie
    point_FitoutPT=size(FitoutPT,1);
    FitoutPT(:,1)=FitoutPT(:,1)+(4000*getnom);
     
        corrx=fidx-cell2mat(fidptchar(ff,5));
        corry=fidy-cell2mat(fidptchar(ff,6));
    
   
    FitoutPT(:,2)=FitoutPT(:,2)+corrx;
    FitoutPT(:,3)=FitoutPT(:,3)+corry;
   
    if (cell2mat(fidptchar(ff,3))=='ex532')
        point_FitoutPT_all_green=size(FitoutPT_all_green,1);
        if (point_FitoutPT_all_green==1)
           FitoutPT_all_green(1:point_FitoutPT,:)=FitoutPT; 
        else
            FitoutPT_all_green((point_FitoutPT_all_green+1):(point_FitoutPT_all_green+point_FitoutPT),:)=FitoutPT;
        end
    end
    if (cell2mat(fidptchar(ff,3))=='ex642')
        
        point_FitoutPT_all_red=size(FitoutPT_all_red,1);
        if (point_FitoutPT_all_red==1)
           FitoutPT_all_red(1:point_FitoutPT,:)=FitoutPT; 
        else
            FitoutPT_all_red((point_FitoutPT_all_red+1):(point_FitoutPT_all_red+point_FitoutPT),:)=FitoutPT;
        end
    end 
end
%% area selection
gg=find(FitoutPT_all_green(:,3)<x_range(1));
FitoutPT_all_green(gg,:)=[];
gg1=find(FitoutPT_all_green(:,3)>x_range(2));
FitoutPT_all_green(gg1,:)=[];
gg2=find(FitoutPT_all_green(:,2)>y_range(2));
FitoutPT_all_green(gg2,:)=[];
gg3=find(FitoutPT_all_green(:,2)<y_range(1));
FitoutPT_all_green(gg3,:)=[];
rr=find(FitoutPT_all_red(:,3)<x_range(1));
FitoutPT_all_red(rr,:)=[];
rr1=find(FitoutPT_all_red(:,3)>x_range(2));
FitoutPT_all_red(rr1,:)=[];
rr2=find(FitoutPT_all_red(:,2)>y_range(2));
FitoutPT_all_red(rr2,:)=[];
rr3=find(FitoutPT_all_red(:,2)<y_range(1));
FitoutPT_all_red(rr3,:)=[];
point_red_total=size(FitoutPT_all_red,1);
point_green_total=size(FitoutPT_all_green,1);
%rr=1;
%gg=1;
%while gg<=point_green_total
%    gg
%   if (FitoutPT_all_green(gg,3)<x_range(1))||(FitoutPT_all_green(gg,3)>x_range(2))||(FitoutPT_all_green(gg,2)<y_range(1))||(FitoutPT_all_green(gg,2)>y_range(2))
%   FitoutPT_all_green(gg,:)=[];
%   gg=gg-1;
%   point_green_total=point_green_total-1;
%   end
%   gg=gg+1;
%end
%while rr<=point_red_total
%    rr
%   if (FitoutPT_all_red(rr,3)<x_range(1))||(FitoutPT_all_red(rr,3)>x_range(2))||(FitoutPT_all_red(rr,2)<y_range(1))||(FitoutPT_all_red(rr,2)>y_range(2))
%   FitoutPT_all_red(rr,:)=[];
%   rr=rr-1;
%   point_red_total=point_red_total-1;
%   end
%   rr=rr+1;
%end
%% find which one has decreased labeling
%if (point_red_total>=point_green_total)
    for gg=1:point_green_total
    points_set_red=zeros(point_red_total,2);
    points_set_red(:,1)=FitoutPT_all_red(:,3);
    points_set_red(:,2)=FitoutPT_all_red(:,2);
    [nearst_distance]=distance_nearest(FitoutPT_all_green(gg,3),FitoutPT_all_green(gg,2),points_set_red,point_red_total);
    Green_distance_distribution(gg)=nearst_distance*66.67;
    end   
    col_counter_green_30=find(Green_distance_distribution<=30);
    col_counter_green_more_than_30=find(Green_distance_distribution>30);
    Col_green(:,1)=FitoutPT_all_green(col_counter_green_30,3);
    Col_green(:,2)=FitoutPT_all_green(col_counter_green_30,2);
    molecule_distribution_green=zeros(20,3);
    for jjjj=1:20
        molecule_distribution_green(jjjj,1)=jjjj*5;
        counter_green=find(Green_distance_distribution<=molecule_distribution_green(jjjj,1));
        molecule_distribution_green(jjjj,2)=size(counter_green,2);
        molecule_distribution_green(jjjj,3)=size(counter_green,2)/size(Green_distance_distribution,2);
    end
    green_hist=(histcounts(Green_distance_distribution,'BinWidth',delta))';
    %area(1)=pi*15^2;
    for iiii=1:size(green_hist,1)
        area(iiii)=pi*delta*[(2*(iiii*delta))+delta];
    end
    for iiii=1:size(green_hist,1)
    point_set_corr_green(iiii)=[(x_range(2)-x_range(1))*(y_range(2)-y_range(1))*green_hist(iiii)]/[area(iiii)*point_green_total];    
    end
    plot_x_green=[0:delta:((size(green_hist,1)-1)*delta)];
    plot(plot_x_green,point_set_corr_green(:))
    saveas(gcf,'green_corr')
    close
    
   % for ggg=1:ceil((size(col_counter_green_more_than_45,2)/2))
   %    FitoutPT_all_green(col_counter_green_more_than_45(ggg),:)=[]; 
   % end
    
%else
    for rr=1:point_red_total
    points_set_green=zeros(point_green_total,2);
    points_set_green(:,1)=FitoutPT_all_green(:,3);
    points_set_green(:,2)=FitoutPT_all_green(:,2);
    [nearst_distance]=distance_nearest(FitoutPT_all_red(rr,3),FitoutPT_all_red(rr,2),points_set_green,point_green_total);
    Red_distance_distribution(rr)=nearst_distance*66.67;
    end
    col_counter_red_30=find(Red_distance_distribution<=30);
    col_counter_red_more_than_30=find(Red_distance_distribution>30);
    molecule_distribution_red=zeros(20,3);
    for jjjj=1:20
        molecule_distribution_red(jjjj,1)=jjjj*5;
        counter_red=find(Red_distance_distribution<=molecule_distribution_red(jjjj,1));
        molecule_distribution_red(jjjj,2)=size(counter_red,2);
        molecule_distribution_red(jjjj,3)=size(counter_red,2)/size(Red_distance_distribution,2);
    end
    Col_red(:,1)=FitoutPT_all_red(col_counter_red_30,3);
    Col_red(:,2)=FitoutPT_all_red(col_counter_red_30,2);
    red_hist=(histcounts(Red_distance_distribution,'BinWidth',delta))';
    for iiii=1:size(red_hist,1)
        area_red(iiii)=pi*delta*[(2*(iiii*delta))+delta];
    end
    for iiii=1:size(red_hist,1)
    point_set_corr_red(iiii)=[(x_range(2)-x_range(1))*(y_range(2)-y_range(1))*red_hist(iiii)]/[area_red(iiii)*point_red_total];    
    end
    plot_x_red=[0:delta:((size(red_hist,1)-1)*delta)];
    plot(plot_x_red,point_set_corr_red(:))
    saveas(gcf,'red_corr')
    close
  %   for rrr=1:ceil((size(col_counter_red_more_than_45,2)/2))
  %     FitoutPT_all_red(col_counter_red_more_than_45(rrr),:)=[]; 
  %     col_counter_red_more_than_45=col_counter_red_more_than_45-1;
  %   end
    %rev=randperm(size(col_counter_red_more_than_45,2),ceil((size(col_counter_red_more_than_45,2)/2)));
    %for rrr=1:size(rev,2)
    %FitoutPT_all_red(rev(rrr), :) = [];
    %iii=find(rev>rev(rrr));
    %rev(iii)=rev(iii)-1;
    %end
    %rev = randi([1 size(col_counter_red_more_than_45,2)],1,ceil((size(col_counter_red_more_than_45,2)/2)));
    %FitoutPT_all_red(rev, :) = [];
    %for rrr=1:ceil((size(col_counter_red_more_than_45,2)/2))
    %    rev = randi([1 size(col_counter_red_more_than_45,2)],1,1);
    %   FitoutPT_all_red(col_counter_red_more_than_45(rev),:)=[]; 
    %   col_counter_red_more_than_45(rev)=[];
    %   for r_change=rev:size(col_counter_red_more_than_45,2)
    %   col_counter_red_more_than_45(r_change)=col_counter_red_more_than_45(r_change)-1;
    %   end
    %end
    
    
%end
%% plotting the figure
cd (Samplpath);
if (exist ('CP_Results')==0)
mkdir(pwd,'CP_Results');
end
cd ('CP_Results');
H=figure;
scatter(FitoutPT_all_green(:,3),FitoutPT_all_green(:,2),10,[0 1 0],'filled')
set(gca,'XTick',[], 'YTick', [])
set(gca,'Color','k')
hold on
line(scale_x,scale_y,'Color','white','LineWidth',3)
axis([x_range y_range]);
hold off
saveas(H,'Green_fig','jpeg');
saveas(H,'Green_fig');
H=figure;
scatter(FitoutPT_all_red(:,3),FitoutPT_all_red(:,2),10,[1 0 0],'filled')
set(gca,'XTick',[], 'YTick', [])
set(gca,'Color','k')
hold on
line(scale_x,scale_y,'Color','white','LineWidth',3)
axis([x_range y_range]);
hold off
saveas(H,'Red_fig','jpeg');
saveas(H,'Red_fig');

if (point_red_total>=point_green_total)
    H=figure;
    %plot(FitoutPT_all_red(:,3),FitoutPT_all_red(:,2),'o','MarkerSize',3,'Color','red')
    %hold on
    scatter(FitoutPT_all_green(:,3),FitoutPT_all_green(:,2),10,[0 1 0],'filled')
    hold on
    scatter(Col_green(:,1),Col_green(:,2),10,[1 1 0],'filled')
    set(gca,'XTick',[], 'YTick', [])
    set(gca,'Color','k')
    hold on
    line(scale_x,scale_y,'Color','white','LineWidth',3)
    axis([x_range y_range]);
    hold off
    saveas(H,'Green_CP30','jpeg');
    saveas(H,'Green_CP30');
    close
else
    H=figure;
    %plot(FitoutPT_all_green(:,3),FitoutPT_all_green(:,2),'o','MarkerSize',3,'Color','green')
    %hold on
    scatter(FitoutPT_all_red(:,3),FitoutPT_all_red(:,2),10,[1 0 0],'filled')
    hold on
    scatter(Col_red(:,1),Col_red(:,2),10,[1 1 0],'filled')
    set(gca,'XTick',[], 'YTick', [])
    set(gca,'Color','k')
    hold on
    line(scale_x,scale_y,'Color','white','LineWidth',3)
    axis([x_range y_range]);
    hold off
    saveas(H,'Red_CP30','jpeg');
    saveas(H,'Red_CP30');
    close
end
save('Col_green.mat','Col_green','-mat')
save('Col_red.mat','Col_red','-mat')
save('FitoutPT_all_red_corrected_modified.mat','FitoutPT_all_red','-mat')
save('FitoutPT_all_green_corrected_modified.mat','FitoutPT_all_green','-mat')
save('dual_color_figure_summary');
if (point_red_total>=point_green_total)
save('molecule_distribution_green.mat','molecule_distribution_green','-mat')
save('molecule_distribution_green.txt','molecule_distribution_green','-ascci')
else
save('molecule_distribution_red.mat','molecule_distribution_red','-mat')
save('molecule_distribution_red.txt','molecule_distribution_red','-ascci')
end
close all;
