function[nearst_distance]=distance_nearest(point_x,point_y,points_set,Number_points)
dist_all=zeros(Number_points,1);
for aa=1:Number_points 
    dist_all(aa,1)=sqrt(((point_x-points_set(aa,1))^2)+((point_y-points_set(aa,2))^2));
end
nearst_distance=min(dist_all);
end